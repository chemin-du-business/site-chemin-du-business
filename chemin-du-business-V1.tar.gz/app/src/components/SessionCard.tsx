import { Calendar, Monitor, Users, CheckCircle, Clock } from 'lucide-react';
import type { Session } from '@/data/sessions';

interface SessionCardProps {
  session: Session;
}

const SessionCard = ({ session }: SessionCardProps) => {
  const getStatutBadge = () => {
    switch (session.statut) {
      case 'disponible':
        return (
          <span className="badge-disponible flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Places disponibles {session.places && `(${session.places})`}
          </span>
        );
      case 'complet':
        return (
          <span className="badge-complet">
            Complet
          </span>
        );
      case 'demande':
        return (
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
            <Clock className="w-3 h-3 mr-1" />
            Sur demande
          </span>
        );
      default:
        return null;
    }
  };

  const getModaliteIcon = () => {
    switch (session.modalite) {
      case 'Distanciel':
        return <Monitor className="w-4 h-4" />;
      case 'Présentiel':
        return <Users className="w-4 h-4" />;
      case 'Hybride':
        return <Monitor className="w-4 h-4" />;
      default:
        return <Monitor className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#0B3D5C]/10 flex items-center justify-center flex-shrink-0">
            <Calendar className="w-5 h-5 text-[#0B3D5C]" />
          </div>
          <div>
            <h4 className="font-medium text-gray-900">{session.formation}</h4>
            <div className="flex items-center gap-3 mt-1 text-sm text-gray-600">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {session.date}
              </span>
              <span className="flex items-center gap-1">
                {getModaliteIcon()}
                {session.modalite}
              </span>
            </div>
          </div>
        </div>
        <div className="flex-shrink-0">
          {getStatutBadge()}
        </div>
      </div>
    </div>
  );
};

export default SessionCard;
