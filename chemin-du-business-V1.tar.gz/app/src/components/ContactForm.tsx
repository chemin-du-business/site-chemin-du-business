import { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';

interface ContactFormProps {
  defaultType?: string;
  showTitle?: boolean;
}

const ContactForm = ({ defaultType = 'informations', showTitle = true }: ContactFormProps) => {
  const [formData, setFormData] = useState({
    prenom: '',
    nom: '',
    email: '',
    telephone: '',
    formation: '',
    dateSouhaitee: '',
    typeDemande: defaultType,
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulation d'envoi
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        prenom: '',
        nom: '',
        email: '',
        telephone: '',
        formation: '',
        dateSouhaitee: '',
        typeDemande: defaultType,
        message: ''
      });
    }, 3000);
  };

  const typeOptions = [
    { value: 'informations', label: 'Demande d\'informations' },
    { value: 'devis', label: 'Demande de devis' },
    { value: 'inscription', label: 'Demande d\'inscription' },
    { value: 'rdv', label: 'Prise de rendez-vous' }
  ];

  const formationOptions = [
    { value: '', label: 'Sélectionnez une formation' },
    { value: 'wordpress', label: 'WordPress (Tosa)' },
    { value: 'ia-python', label: 'IA & Python (Tosa)' },
    { value: 'autre', label: 'Autre / Je ne sais pas encore' }
  ];

  if (isSubmitted) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-green-800 mb-2">
          Votre demande a été envoyée
        </h3>
        <p className="text-green-700">
          Nous vous recontacterons dans les meilleurs délais.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {showTitle && (
        <div className="mb-6">
          <h3 className="text-xl font-semibold text-[#0B3D5C] mb-2">
            Formulaire de contact
          </h3>
          <p className="text-gray-600 text-sm">
            Remplissez le formulaire ci-dessous, nous vous recontacterons rapidement.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Prénom <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            name="prenom"
            value={formData.prenom}
            onChange={handleChange}
            required
            className="input-field"
            placeholder="Votre prénom"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Nom <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            name="nom"
            value={formData.nom}
            onChange={handleChange}
            required
            className="input-field"
            placeholder="Votre nom"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Adresse email <span className="text-red-500">*</span>
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="input-field"
            placeholder="votre@email.com"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Numéro de téléphone
          </label>
          <input
            type="tel"
            name="telephone"
            value={formData.telephone}
            onChange={handleChange}
            className="input-field"
            placeholder="01 23 45 67 89"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Formation souhaitée
          </label>
          <select
            name="formation"
            value={formData.formation}
            onChange={handleChange}
            className="input-field"
          >
            {formationOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Type de demande
          </label>
          <select
            name="typeDemande"
            value={formData.typeDemande}
            onChange={handleChange}
            className="input-field"
          >
            {typeOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Date de formation souhaitée
        </label>
        <input
          type="date"
          name="dateSouhaitee"
          value={formData.dateSouhaitee}
          onChange={handleChange}
          className="input-field"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Message
        </label>
        <textarea
          name="message"
          value={formData.message}
          onChange={handleChange}
          rows={4}
          className="input-field resize-none"
          placeholder="Décrivez votre demande..."
        />
      </div>

      <button
        type="submit"
        className="w-full btn-primary flex items-center justify-center gap-2"
      >
        <Send className="w-4 h-4" />
        Envoyer ma demande
      </button>

      <p className="text-xs text-gray-500 text-center">
        Nous vous recontactons dans les meilleurs délais.
      </p>
    </form>
  );
};

export default ContactForm;
