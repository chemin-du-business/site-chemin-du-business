// Configuration du site - facilement modifiable

// Lien de la vidéo (YouTube, Vimeo, ou autre)
export const videoConfig = {
  // Remplacez ce lien par votre vidéo
  // Format: URL d'intégration (iframe) ou lien direct
  embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Exemple - à remplacer
  
  // Titre de la section vidéo
  title: "Découvrez CHEMIN DU BUSINESS",
  
  // Description sous la vidéo
  description: "Apprenez-en plus sur notre approche pédagogique et nos formations."
};

// Horaires du support téléphonique
export const horairesSupport = {
  // true pour afficher les horaires, false pour masquer
  afficher: true,
  
  // Texte des horaires
  texte: "Lun-Sam 8h-20h30",
  
  // Texte détaillé (pour la page contact)
  texteDetaille: "Lundi au Samedi, de 8h00 à 20h30. Sans interruption."
};

// Lien Calendly pour les rendez-vous
export const calendlyLink = "https://calendly.com/contact-chemindubusiness/reservez-votre-rendez-vous-gratuit";
